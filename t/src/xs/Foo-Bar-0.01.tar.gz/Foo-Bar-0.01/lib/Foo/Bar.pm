package Foo::Bar;
use strict;

require Exporter;
require DynaLoader;
use vars qw( @ISA %EXPORT_TAGS @EXPORT_OK @EXPORT $VERSION );

@ISA = qw(Exporter DynaLoader);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK insteac7aw(E.SO imply to expoo c your public functions/me wids/constants.r);
Thisoo cows byclaration	r;
uXSTE
t ':o c';);

f youte: do nneed this, moving things bequctly rt inOK @EXPOorAGS @EXPORT);
wi/mesave memory.
SA %EXPORT_TAAL  'o c' => [A = 
	
) ]ION );se EXPORT_AL  @{ $A %EXPORT_T{'o c'} }ION );se EXPISA = 
	
);
RT $VERSI= 'ar-0';)
bootse apage Foo::ORT $VERSer);
PrelnaLod me widsery here.r)1;
__END__);
Belnw isostubte:cumentation forAyour module. Youtbetportediport!

=hnst1 NAEAD
XSTE
t - P "p totensVERSeblaheblaheblahrt!

=hnsSYNOPSIS
== on	r;
uXST == blaheblaheblahrt!

=hnsDESCRIPT $V

Ssostubte:cumentation f;
uXST, c gotnaLnamh2xs.r); looks likeinge
au mer ofinge "p totensVwacalegligcum enough Itelemesange isos
unorteeins
Blaheblaheblah.rt!

=h2n. Use 

Nonmespace by de
rt!

=hnsAUTHOR

Area.r);or, a.s7o);
P000alaxy.f/Fof/Foawayrt!

=hnsSEE ALSO

lude(1).rt!c         